# Test Cases

| ID | Test | Steps / Input | Expected Result |
|---|---|---|---|
| TC01 | Add valid game | Enter valid title, genre, platform, year and type | Game is added |
| TC02 | Empty title | Submit an empty title | Prompt asks for non-empty input |
| TC03 | Duplicate game | Add same title and platform twice | Duplicate is rejected |
| TC04 | View library | Choose View all games | All saved/in-memory games are listed |
| TC05 | Search title | Search by full or partial title | Matching games appear |
| TC06 | Filter genre | Enter a genre | Games in that genre appear |
| TC07 | Update status | Change a game's status | New status is displayed |
| TC08 | Rate incomplete game | Try rating a game not marked Completed | Rating is blocked |
| TC09 | Rate completed game | Mark completed, enter 8.5 | Rating is saved |
| TC10 | Invalid rating | Enter a value outside 0–10 | Input is rejected |
| TC11 | Persistence | Save, exit, relaunch | Saved games load again |
| TC12 | Remove game | Select a title and remove it | Game disappears from library |
| TC13 | Invalid year | Enter year outside 1950–2100 | Input is rejected |
| TC14 | Statistics | Open statistics | Counts and average rating are displayed |

Before submission, execute these tests on the computer used for the demonstration and record actual results.
