# Game Library and Backlog Management System

A Java console application for managing a personal video-game collection.

## Features
- Add, list, search, filter, update, rate, and remove games
- Track Not Started / Playing / Completed status
- Statistics for collection size, progress, and average rating
- Save/load data in `data/games.txt`
- Input validation and exception handling

## Requirements
Java Development Kit (JDK) 8 or newer.

## Run on Windows
1. Open a terminal in this folder.
2. Run `run.bat`.
3. The application creates `data/games.txt` when saving for the first time.

## Run on macOS/Linux
Run `chmod +x run.sh` once, then `./run.sh`.

## Compile manually
`javac -d out src/com/gamelibrary/model/*.java src/com/gamelibrary/service/*.java src/com/gamelibrary/storage/*.java src/com/gamelibrary/ui/*.java`
Then run `java -cp out com.gamelibrary.ui.Main`.

## OOP concepts demonstrated
- Encapsulation: private fields and validation setters in `Game`
- Abstraction: abstract `Game` class
- Inheritance: `PCGame` and `ConsoleGame` extend `Game`
- Polymorphism: `getGameType()` is overridden in subclasses
- Interfaces: `Trackable`, `Rateable`, and generic `Repository<T>`
- Collections and generics: `List<Game>`, `ArrayList<Game>`, `Repository<T>`
- File handling: `FileManager` uses buffered text file I/O
- Exception handling: invalid input, duplicate entries, and file errors
- Packages: `model`, `service`, `storage`, and `ui`

## Notes
This is a console-based educational project. Review the code and personalize the report and slides with your team members' names, roll numbers, class/division, and faculty details before submission.
