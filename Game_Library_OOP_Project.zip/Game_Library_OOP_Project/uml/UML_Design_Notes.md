# UML Design Notes

## Main relationships
- `PCGame` and `ConsoleGame` inherit from abstract `Game`.
- `Game` implements `Trackable` and `Rateable`.
- `GameLibrary` implements generic `Repository<Game>` and manages a collection of `Game` objects.
- `Main` uses `GameLibrary` and `FileManager`.
- `FileManager` serializes and restores game objects using a text file.
- `Game` uses the `GameStatus` enum.

Open `GameLibrary_UML.puml` in a PlantUML-compatible viewer/editor to render the class diagram. The `.puml` source is the editable UML design document.
