#!/bin/sh
set -e
mkdir -p out
javac -encoding UTF-8 -d out src/com/gamelibrary/model/*.java src/com/gamelibrary/service/*.java src/com/gamelibrary/storage/*.java src/com/gamelibrary/ui/*.java
java -cp out com.gamelibrary.ui.Main
