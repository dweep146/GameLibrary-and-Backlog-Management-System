package com.gamelibrary.storage;

import com.gamelibrary.model.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class FileManager {
    private final Path file;

    public FileManager(String filePath) { this.file = Paths.get(filePath); }

    public void save(List<Game> games) throws IOException {
        Path parent = file.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        try (BufferedWriter writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            writer.write("# Game Library data file - do not remove the header");
            writer.newLine();
            for (Game game : games) {
                writer.write(game.toCsv());
                writer.newLine();
            }
        }
    }

    public List<Game> load() throws IOException {
        List<Game> result = new ArrayList<>();
        if (!Files.exists(file)) return result;
        List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        int lineNumber = 0;
        for (String line : lines) {
            lineNumber++;
            if (line.trim().isEmpty() || line.startsWith("#")) continue;
            String[] p = line.split("\\|", -1);
            if (p.length != 7) {
                throw new IOException("Invalid data format at line " + lineNumber + ".");
            }
            try {
                String title = Game.unescape(p[0]);
                String genre = Game.unescape(p[1]);
                String platform = Game.unescape(p[2]);
                int year = Integer.parseInt(p[3]);
                Game game = "PC".equalsIgnoreCase(p[6])
                        ? new PCGame(title, genre, platform, year)
                        : new ConsoleGame(title, genre, platform, year);
                game.updateStatus(GameStatus.valueOf(p[4]));
                double rating = Double.parseDouble(p[5]);
                if (rating > 0) game.setRating(rating);
                result.add(game);
            } catch (RuntimeException ex) {
                throw new IOException("Invalid game data at line " + lineNumber + ": " + ex.getMessage(), ex);
            }
        }
        return result;
    }
}
