package com.gamelibrary.service;

import com.gamelibrary.model.*;
import java.util.*;
import java.util.stream.Collectors;

public class GameLibrary implements Repository<Game> {
    private final List<Game> games = new ArrayList<>();

    @Override public void add(Game game) {
        Objects.requireNonNull(game, "Game cannot be null.");
        if (games.contains(game)) throw new IllegalArgumentException("A game with the same title and platform already exists.");
        games.add(game);
    }
    @Override public boolean remove(Game game) { return games.remove(game); }
    @Override public List<Game> getAll() { return new ArrayList<>(games); }
    @Override public Optional<Game> findByName(String name) {
        if (name == null) return Optional.empty();
        return games.stream().filter(g -> g.getTitle().equalsIgnoreCase(name.trim())).findFirst();
    }
    public List<Game> searchTitle(String query) {
        String q = query == null ? "" : query.trim().toLowerCase();
        return games.stream().filter(g -> g.getTitle().toLowerCase().contains(q)).collect(Collectors.toList());
    }
    public List<Game> filterGenre(String genre) {
        return games.stream().filter(g -> g.getGenre().equalsIgnoreCase(genre.trim())).collect(Collectors.toList());
    }
    public List<Game> filterPlatform(String platform) {
        return games.stream().filter(g -> g.getPlatform().equalsIgnoreCase(platform.trim())).collect(Collectors.toList());
    }
    public long countStatus(GameStatus status) {
        return games.stream().filter(g -> g.getStatus() == status).count();
    }
    public double averageRating() {
        return games.stream().filter(g -> g.getRating() > 0).mapToDouble(Game::getRating).average().orElse(0.0);
    }
    public void clearAndReplace(Collection<Game> loaded) {
        games.clear();
        for (Game g : loaded) add(g);
    }
}
