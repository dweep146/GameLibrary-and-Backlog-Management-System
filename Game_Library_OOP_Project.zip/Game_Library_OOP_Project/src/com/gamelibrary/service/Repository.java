package com.gamelibrary.service;

import java.util.List;
import java.util.Optional;

public interface Repository<T> {
    void add(T item);
    boolean remove(T item);
    List<T> getAll();
    Optional<T> findByName(String name);
}
