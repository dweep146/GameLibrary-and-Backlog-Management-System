package com.gamelibrary.model;

public abstract class Game implements Trackable, Rateable {

    private String title;
    private String genre;
    private String platform;
    private int releaseYear;
    private GameStatus status;
    private double rating;

    protected Game(String title, String genre, String platform, int releaseYear) {
        setTitle(title);
        setGenre(genre);
        setPlatform(platform);
        setReleaseYear(releaseYear);
        this.status = GameStatus.NOT_STARTED;
        this.rating = 0.0;
    }

    public abstract String getGameType();

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public String getPlatform() {
        return platform;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    @Override
    public GameStatus getStatus() {
        return status;
    }

    @Override
    public double getRating() {
        return rating;
    }

    public void setTitle(String title) {
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Title cannot be empty.");
        }
        this.title = title.trim();
    }

    public void setGenre(String genre) {
        if (genre == null || genre.trim().isEmpty()) {
            throw new IllegalArgumentException("Genre cannot be empty.");
        }
        this.genre = genre.trim();
    }

    public void setPlatform(String platform) {
        if (platform == null || platform.trim().isEmpty()) {
            throw new IllegalArgumentException("Platform cannot be empty.");
        }
        this.platform = platform.trim();
    }

    public void setReleaseYear(int year) {
        if (year < 1950 || year > 2100) {
            throw new IllegalArgumentException(
                "Release year must be between 1950 and 2100."
            );
        }
        this.releaseYear = year;
    }

    @Override
    public void updateStatus(GameStatus status) {
        if (status == null) {
            throw new IllegalArgumentException("Status is required.");
        }
        this.status = status;
    }

    @Override
    public void setRating(double rating) {
        if (rating < 0 || rating > 10 || Double.isNaN(rating)) {
            throw new IllegalArgumentException(
                "Rating must be between 0 and 10."
            );
        }

        if (rating > 0 && status != GameStatus.COMPLETED) {
            throw new IllegalStateException(
                "Only completed games can be rated."
            );
        }

        this.rating = rating;
    }

    public String toCsv() {
        return String.join("|",
            escape(title),
            escape(genre),
            escape(platform),
            Integer.toString(releaseYear),
            status.name(),
            Double.toString(rating),
            getGameType()
        );
    }

    public static String escape(String value) {
        return value.replace("\\", "\\\\")
                    .replace("|", "\\p")
                    .replace("\n", "\\n")
                    .replace("\r", "");
    }

    public static String unescape(String value) {
        StringBuilder out = new StringBuilder();
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);

            if (escaped) {
                if (c == 'p') {
                    out.append('|');
                } else if (c == 'n') {
                    out.append('\n');
                } else {
                    out.append(c);
                }
                escaped = false;
            } else if (c == '\\') {
                escaped = true;
            } else {
                out.append(c);
            }
        }

        if (escaped) {
            out.append('\\');
        }

        return out.toString();
    }

    @Override
    public String toString() {
        return String.format(
            "%-24s | %-14s | %-10s | %4d | %-11s | %5s | %s",
            title,
            genre,
            platform,
            releaseYear,
            status,
            rating == 0 ? "N/A" : String.format("%.1f", rating),
            getGameType()
        );
    }
}