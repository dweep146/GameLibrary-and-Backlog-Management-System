package com.gamelibrary.model;

public interface Rateable {
    void setRating(double rating);
    double getRating();
}
