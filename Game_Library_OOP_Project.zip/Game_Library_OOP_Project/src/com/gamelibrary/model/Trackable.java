package com.gamelibrary.model;

public interface Trackable {
    void updateStatus(GameStatus status);
    GameStatus getStatus();
}
