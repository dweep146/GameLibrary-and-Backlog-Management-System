package com.gamelibrary.model;

public enum GameStatus {
    NOT_STARTED,
    PLAYING,
    COMPLETED
}
