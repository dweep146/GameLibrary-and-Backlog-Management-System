package com.gamelibrary.model;

public class PCGame extends Game {
    public PCGame(String title, String genre, String platform, int releaseYear) {
        super(title, genre, platform, releaseYear);
    }

    @Override
    public String getGameType() {
        return "PC";
    }
}