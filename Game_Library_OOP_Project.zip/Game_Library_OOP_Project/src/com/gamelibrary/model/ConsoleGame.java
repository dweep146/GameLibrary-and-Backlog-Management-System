package com.gamelibrary.model;

public class ConsoleGame extends Game {
    public ConsoleGame(String title, String genre, String platform, int releaseYear) {
        super(title, genre, platform, releaseYear);
    }

    @Override
    public String getGameType() {
        return "Console";
    }
}