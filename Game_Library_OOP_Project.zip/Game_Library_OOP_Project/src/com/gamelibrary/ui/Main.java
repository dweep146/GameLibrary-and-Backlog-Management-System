package com.gamelibrary.ui;

import com.gamelibrary.model.*;
import com.gamelibrary.service.GameLibrary;
import com.gamelibrary.storage.FileManager;
import java.io.IOException;
import java.util.*;

public class Main {
    private static final Scanner INPUT = new Scanner(System.in);
    private static final GameLibrary LIBRARY = new GameLibrary();
    private static final FileManager FILES = new FileManager("data/games.txt");

    public static void main(String[] args) {
        try {
            LIBRARY.clearAndReplace(FILES.load());
            System.out.println("Loaded " + LIBRARY.getAll().size() + " game(s).");
        } catch (IOException | IllegalArgumentException ex) {
            System.out.println("Could not load saved data: " + ex.getMessage());
            System.out.println("Starting with an empty library.");
        }
        boolean running = true;
        while (running) {
            menu();
            int choice = readInt("Choose an option: ", 0, 10);
            try {
                switch (choice) {
                    case 1: addGame(); break;
                    case 2: showGames(LIBRARY.getAll()); break;
                    case 3: searchGame(); break;
                    case 4: updateStatus(); break;
                    case 5: rateGame(); break;
                    case 6: removeGame(); break;
                    case 7: filterGenre(); break;
                    case 8: filterPlatform(); break;
                    case 9: statistics(); break;
                    case 10: save(); break;
                    case 0:
                        save();
                        running = false;
                        System.out.println("Goodbye! Your library has been saved.");
                        break;
                    default: break;
                }
            } catch (IllegalArgumentException | IllegalStateException ex) {
                System.out.println("Error: " + ex.getMessage());
            }
        }
        INPUT.close();
    }

    private static void menu() {
        System.out.println("\n========== GAME LIBRARY & BACKLOG ==========");
        System.out.println("1. Add game");
        System.out.println("2. View all games");
        System.out.println("3. Search by title");
        System.out.println("4. Update playing status");
        System.out.println("5. Rate a completed game");
        System.out.println("6. Remove game");
        System.out.println("7. Filter by genre");
        System.out.println("8. Filter by platform");
        System.out.println("9. Library statistics");
        System.out.println("10. Save library");
        System.out.println("0. Save and exit");
    }

    private static void addGame() {
        String title = readText("Title: ");
        String genre = readText("Genre: ");
        String platform = readText("Platform (e.g., Windows, PS5, Xbox): ");
        int year = readInt("Release year (1950-2100): ", 1950, 2100);
        int type = readInt("Game type: 1. PC  2. Console: ", 1, 2);
        Game game = type == 1 ? new PCGame(title, genre, platform, year)
                              : new ConsoleGame(title, genre, platform, year);
        LIBRARY.add(game);
        System.out.println("Game added successfully.");
    }

    private static void searchGame() {
        String query = readText("Enter title or part of title: ");
        showGames(LIBRARY.searchTitle(query));
    }

    private static void updateStatus() {
        Game game = chooseGame();
        if (game == null) return;
        System.out.println("1. Not started  2. Playing  3. Completed");
        int status = readInt("New status: ", 1, 3);
        game.updateStatus(GameStatus.values()[status - 1]);
        System.out.println("Status updated.");
    }

    private static void rateGame() {
        Game game = chooseGame();
        if (game == null) return;
        if (game.getStatus() != GameStatus.COMPLETED) {
            System.out.println("Mark this game as Completed before rating it.");
            return;
        }
        double rating = readDouble("Rating (0-10): ", 0, 10);
        game.setRating(rating);
        System.out.println("Rating saved.");
    }

    private static void removeGame() {
        Game game = chooseGame();
        if (game == null) return;
        if (LIBRARY.remove(game)) System.out.println("Game removed.");
        else System.out.println("Game could not be removed.");
    }

    private static void filterGenre() { showGames(LIBRARY.filterGenre(readText("Genre: "))); }
    private static void filterPlatform() { showGames(LIBRARY.filterPlatform(readText("Platform: "))); }

    private static Game chooseGame() {
        String title = readText("Enter exact game title: ");
        Optional<Game> found = LIBRARY.findByName(title);
        if (!found.isPresent()) {
            System.out.println("Game not found.");
            return null;
        }
        return found.get();
    }

    private static void statistics() {
        System.out.println("\\n========== LIBRARY STATISTICS ==========");
        System.out.println("Total games: " + LIBRARY.getAll().size());
        System.out.println("Not started: " + LIBRARY.countStatus(GameStatus.NOT_STARTED));
        System.out.println("Playing: " + LIBRARY.countStatus(GameStatus.PLAYING));
        System.out.println("Completed: " + LIBRARY.countStatus(GameStatus.COMPLETED));
        System.out.printf(Locale.US, "Average rating: %.2f/10%n", LIBRARY.averageRating());
    }

    private static void showGames(List<Game> games) {
        if (games.isEmpty()) {
            System.out.println("No games found.");
            return;
        }
        System.out.printf("%-24s | %-14s | %-10s | %4s | %-11s | %5s | %s%n",
                "TITLE", "GENRE", "PLATFORM", "YEAR", "STATUS", "RATING", "TYPE");
        System.out.println("-----------------------------------------------------------------------------------------------");
        for (Game game : games) System.out.println(game);
    }

    private static void save() {
        try {
            FILES.save(LIBRARY.getAll());
            System.out.println("Library saved to data/games.txt.");
        } catch (IOException ex) {
            System.out.println("Could not save library: " + ex.getMessage());
        }
    }

    private static String readText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = INPUT.nextLine().trim();
            if (!value.isEmpty()) return value;
            System.out.println("Input cannot be empty.");
        }
    }
    private static int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String value = INPUT.nextLine().trim();
            try {
                int number = Integer.parseInt(value);
                if (number >= min && number <= max) return number;
            } catch (NumberFormatException ignored) { }
            System.out.println("Enter a whole number from " + min + " to " + max + ".");
        }
    }
    private static double readDouble(String prompt, double min, double max) {
        while (true) {
            System.out.print(prompt);
            String value = INPUT.nextLine().trim();
            try {
                double number = Double.parseDouble(value);
                if (number >= min && number <= max && !Double.isNaN(number)) return number;
            } catch (NumberFormatException ignored) { }
            System.out.println("Enter a number from " + min + " to " + max + ".");
        }
    }
}
