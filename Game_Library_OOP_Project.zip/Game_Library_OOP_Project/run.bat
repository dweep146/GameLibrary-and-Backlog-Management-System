
@echo off
cd /d "%~dp0"
javac -d out -sourcepath src src/com/gamelibrary/ui/Main.java
if errorlevel 1 (
    pause
    exit /b 1
)
java -cp out com.gamelibrary.ui.Main
pause
